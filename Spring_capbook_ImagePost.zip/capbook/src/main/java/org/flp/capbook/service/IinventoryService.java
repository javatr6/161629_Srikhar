package org.flp.capbook.service;

import org.flp.capbook.model.Status;



public interface IinventoryService {

	

	

	

	Boolean saveImage(Status status);


	

	

}
