package org.flp.capbook.model;


import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Transient;

@Entity
public class Status {
		@Id
		@GeneratedValue
		private Integer status_id;
		private String statusText;
		private String imageUrl;
		//private Integer comment_id;
		//private  Integer user_id;
		
		
		@OneToMany(mappedBy="status",targetEntity=Comments.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY) 
		private List<Comments> comments;	

		@ManyToOne
		@JoinColumn(name="userId")
		private UserProfile user;
		
		
		private String userName;
		
		@Transient
		private File file;
		
		public Status() {
			super();
			
		}
		
		

		public Status(Integer status_id, String statusText, String imageUrl, List<Comments> comments, UserProfile user,
				String userName, File file) {
			super();
			this.status_id = status_id;
			this.statusText = statusText;
			this.imageUrl = imageUrl;
			this.comments = comments;
			this.user = user;
			this.userName = userName;
			this.file = file;
		}



		public Status(Integer status_id, String statusText, String imageUrl, File file,
				List<Comments> comments, UserProfile user) {
			super();
			this.status_id = status_id;
			this.statusText = statusText;
			this.imageUrl = imageUrl;
			//this.user_id = user_id;
			this.file = file;
			this.comments = comments;
			this.user = user;
		}

		public Status(Integer status_id, String statusText,File file, List<Comments> comments,
				UserProfile user) {
			super();
			this.status_id = status_id;
			this.statusText = statusText;
		//	this.user_id = user_id;
			this.file = file;
			this.comments = comments;
			this.user = user;
		}
		
		

	

		public Status(Integer status_id, String statusText, UserProfile user, File file) {
			super();
			this.status_id = status_id;
			this.statusText = statusText;
			this.user = user;
			this.file = file;
		}

		public Status(String statusText, File file, UserProfile user) {
			super();
			this.statusText = statusText;
			this.user = user;
		}

		public Integer getStatus_id() {
			return status_id;
		}

		public void setStatus_id(Integer status_id) {
			this.status_id = status_id;
		}



		public String getStatusText() {
			return statusText;
		}

		public void setStatusText(String statusText) {
			this.statusText = statusText;
		}

		public String getImageUrl() {
			return imageUrl;
		}

		public void setImageUrl(String imageUrl) {
			this.imageUrl = imageUrl;
		}

		

		public File getFile() {
			return file;
		}

		public void setFile(File file) {
			this.file = file;
		}

		public List<Comments> getComments() {
			return comments;
		}

		public void setComments(List<Comments> comments) {
			this.comments = comments;
		}

		public UserProfile getUser() {
			return user;
		}

		public void setUser(UserProfile user) {
			this.user = user;
		}
		
		

		public String getUserName() {
			return userName;
		}



		public void setUserName(String userName) {
			this.userName = userName;
		}



		@Override
		public String toString() {
			return "Status [status_id=" + status_id + ", statusText=" + statusText + ", imageUrl=" + imageUrl
					+ ", comments=" + comments + ", user=" + user + ", userName=" + userName + ", file=" + file + "]";
		}



		
}