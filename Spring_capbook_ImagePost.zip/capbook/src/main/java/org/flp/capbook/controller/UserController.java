package org.flp.capbook.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.flp.capbook.model.Status;
import org.flp.capbook.service.IinventoryService;
import org.flp.capbook.service.StorageService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;







@RestController
@CrossOrigin(origins="*")
public class UserController {
	@Autowired
	private IinventoryService inventoryService;
	

	@Value("${upload.path}")
    private String path;

	List<String> files1 = new ArrayList<String>();

	@Autowired
	StorageService profileService;
 
	List<String> files = new ArrayList<String>();
 
	@PostMapping("/saveImage/{status}/{userId}")
	public ResponseEntity<String> handleFileUpload(@RequestParam("file") MultipartFile file,@PathVariable("status") String status,@PathVariable("userId") Integer userId) {
		String message = "";
		System.out.println(status);
		
		try {
			profileService.store(status,file,path,userId);
			files.add(file.getOriginalFilename());
 
			message = "You successfully uploaded " + file.getOriginalFilename() + "!";
			System.out.println(message);
			return ResponseEntity.status(HttpStatus.OK).body(message);
		} catch (Exception e) {
			message = "FAIL to upload " + file.getOriginalFilename() + "!";
			System.out.println(e.getMessage());
			System.out.println(message);
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(message);
		}
	}
		
	
	@GetMapping("/getStatus/{userId}")
	public ResponseEntity<List<Status>> getStatus(@PathVariable("userId")Integer userId){
		
		List<Status> status = profileService.getStatus(userId);
		
		return ResponseEntity.status(HttpStatus.OK).body(status);
		
	}
			
	@GetMapping("/getallfiles/{userId}")
	public ResponseEntity<List<String>> getListFiles(Model model,@PathVariable("userId")Integer userId) {
		
		files1=profileService.getAllFiles(userId);
		System.out.println("files in controller");
		System.out.println(files1);
		List<String> fileNames = files1
				.stream().map(fileName -> MvcUriComponentsBuilder
						.fromMethodName(UserController.class, "getFile", fileName,userId).build().toString())
				.collect(Collectors.toList());

		return ResponseEntity.ok().body(fileNames);
	}

	@GetMapping("/files/{filename:.+}/{userId}")
	@ResponseBody
	public ResponseEntity<Resource> getFile(@PathVariable String filename,@PathVariable("userId")Integer userId) {
		Resource file = profileService.loadFile(filename,userId);
		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
				.body(file);
	}
}
