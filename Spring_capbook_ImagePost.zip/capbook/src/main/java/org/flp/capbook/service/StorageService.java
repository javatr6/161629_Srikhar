package org.flp.capbook.service;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.flp.capbook.dao.IStatusDao;
import org.flp.capbook.dao.IUserProfileDao;
import org.flp.capbook.model.Status;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

@Service("profileService")
public class StorageService {
	
	@Autowired
	private IStatusDao statusDao; 
	
	
	@Autowired
	private IUserProfileDao userDao; 
	Logger log = LoggerFactory.getLogger(this.getClass().getName());
	
	private  final Path rootLocation=Paths.get("C:\\Users\\aravitej\\git\\capbook\\src\\main\\resources\\static\\Status");
	
 
	public void store(String status,MultipartFile file,String path,Integer userId) {
		
	
	
		
		
		try {
			
			init();
			Files.copy(file.getInputStream(), this.rootLocation.resolve(file.getOriginalFilename()));
			Status image =new Status(); 
			String userName=userDao.getUserName(userId);
			image.setImageUrl(this.rootLocation.resolve(file.getOriginalFilename()).toString());
			image.setStatusText(status);
			image.setUserName(userName);
			statusDao.save(image);  
		} catch (Exception e) {
			throw new RuntimeException("FAIL!");
		}
	}
 
	public Resource loadFile(String filename, Integer userId) {
		
		//Path rootLocation = Paths.get(path);
		try {
			Path file = rootLocation.resolve(filename);
			Resource resource = new UrlResource(file.toUri());
			if (resource.exists() || resource.isReadable()) {
				return resource;
			} else {
				throw new RuntimeException("FAIL!");
			}
		} catch (MalformedURLException e) {
			throw new RuntimeException("FAIL!");
		}
	}
 
	public void deleteAll() {
	//	Path rootLocation = Paths.get(path);
		FileSystemUtils.deleteRecursively(rootLocation.toFile());
	}
 
	public void init() {
		
		try {
			File file=new File(this.rootLocation.toUri());
			if(!file.isDirectory())
				Files.createDirectory(rootLocation);
		} catch (IOException e) {
			throw new RuntimeException("Could not initialize storage!");
		}
	}

	public List<String> getAllFiles(Integer userId) {
		List<String> files1=new ArrayList<>();
		List<String> files=statusDao.getImage(userId);
		for(String url:files) {
			File file=new File(url);
			files1.add(file.getName());
		}
		return files1;
	}

	public List<Status> getStatus(Integer userId) {
		
		return statusDao.GetStatus(userId);
	}
}
