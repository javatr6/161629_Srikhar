package org.flp.capbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapBookApplication.class, args);
	}

}

