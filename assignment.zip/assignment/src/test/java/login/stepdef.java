package login;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {
	private WebDriver webdriver;
	private WebElement webelement;
	@Before
	public void Setup() {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
		 webdriver=new ChromeDriver();
	}
	@Given("^username and password$")
	public void username_and_password() throws Throwable {
		webdriver.get("file:///D:/MyWork/assignment/src/main/webapp/pages/login.html");
		String innerText=webdriver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
		assertEquals("Hotel Booking Application", innerText);
	    webdriver.findElement(By.name("userName")).sendKeys("Capgemini");
	    webdriver.findElement(By.name("userPwd")).sendKeys("capg1234");
	}

	@When("^valid username and password$")
	public void valid_username_and_password() throws Throwable {
		webelement=webdriver.findElement(By.name("submit"));
	      webelement.submit();
	}

	@Then("^navigate to hotel booking page$")
	public void navigate_to_hotel_booking_page() throws Throwable {
		webdriver.navigate().to("file:///D:/MyWork/assignment/src/main/webapp/pages/hotelbooking.html"); 
	}

	@Given("^password$")
	public void password() throws Throwable {
		webdriver.get("file:///D:/MyWork/assignment/src/main/webapp/pages/login.html");
	}

	@When("^valid password and submit$")
	public void valid_password_and_submit() throws Throwable {
		webelement=webdriver.findElement(By.name("submit"));
	      webelement.click();
	}

	@Then("^show error message ' \\* Please enter userName\\.'$")
	public void show_error_message_Please_enter_userName() throws Throwable {
		String innerText=webdriver.findElement(By.xpath("//*[@id=\"userErrMsg\"]")).getText();
		assertEquals("* Please enter userName.", innerText);
		Thread.sleep(1000);
	}

	@Given("^username$")
	public void username() throws Throwable {
		webdriver.get("file:///D:/MyWork/assignment/src/main/webapp/pages/login.html");
		 webdriver.findElement(By.name("userName")).sendKeys("Capgemini");
	}

	@When("^valid username and submit$")
	public void valid_username_and_submit() throws Throwable {
		webelement=webdriver.findElement(By.name("submit"));
	      webelement.click();
	}

	@Then("^show error message ' \\* Please enter password\\.'$")
	public void show_error_message_Please_enter_password() throws Throwable {
		String innerText=webdriver.findElement(By.xpath("//*[@id=\"pwdErrMsg\"]")).getText();
		assertEquals("* Please enter password.", innerText);
		Thread.sleep(1000);
	}


}
