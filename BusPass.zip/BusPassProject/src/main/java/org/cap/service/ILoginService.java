package org.cap.service;

import org.cap.bean.BusBean;
import org.cap.bean.LoginBean;

public interface ILoginService {
	public boolean isValidLogin(LoginBean loginBean);
	public BusBean createRequest(BusBean busBean);

}
