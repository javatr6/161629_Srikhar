package org.cap.bean;

public class RouteBean {
	private Integer routeid;
	private String routepath;
	private String routename;
	private int totalseats;
	private int occupiedseats;
	private String busno;
	private String driverno;
	private int totalkms;
	public RouteBean() {
		
	}
	public RouteBean(Integer routeid, String routepath, String routename, int totalseats, int occupiedseats,
			String busno, String driverno, int totalkms) {
		super();
		this.routeid = routeid;
		this.routepath = routepath;
		this.routename = routename;
		this.totalseats = totalseats;
		this.occupiedseats = occupiedseats;
		this.busno = busno;
		this.driverno = driverno;
		this.totalkms = totalkms;
	}
	public Integer getRouteid() {
		return routeid;
	}
	public void setRouteid(Integer routeid) {
		this.routeid = routeid;
	}
	public String getRoutepath() {
		return routepath;
	}
	public void setRoutepath(String routepath) {
		this.routepath = routepath;
	}
	public String getRoutename() {
		return routename;
	}
	public void setRoutename(String routename) {
		this.routename = routename;
	}
	public int getTotalseats() {
		return totalseats;
	}
	public void setTotalseats(int totalseats) {
		this.totalseats = totalseats;
	}
	public int getOccupiedseats() {
		return occupiedseats;
	}
	public void setOccupiedseats(int occupiedseats) {
		this.occupiedseats = occupiedseats;
	}
	public String getBusno() {
		return busno;
	}
	public void setBusno(String busno) {
		this.busno = busno;
	}
	public String getDriverno() {
		return driverno;
	}
	public void setDriverno(String driverno) {
		this.driverno = driverno;
	}
	public int getTotalkms() {
		return totalkms;
	}
	public void setTotalkms(int totalkms) {
		this.totalkms = totalkms;
	}
	@Override
	public String toString() {
		return "RouteBean [routeid=" + routeid + ", routepath=" + routepath + ", routename=" + routename
				+ ", totalseats=" + totalseats + ", occupiedseats=" + occupiedseats + ", busno=" + busno + ", driverno="
				+ driverno + ", totalkms=" + totalkms + "]";
	}
	
}
