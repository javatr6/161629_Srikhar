create table BusPassRequest(requestId int primary key auto_increment,EmployeeId varchar(10),
firstname varchar(20),lastname varchar(20),gender varchar(6),address varchar(100),email varchar(100),
dateofjoin date,location varchar(100),pickuploc varchar(20),pickuptime time,status varchar(10),designation varchar(20));
 
create table route(routeid int primary key auto_increment, routename varchar(25),routepath varchar(255) not null, totalseats int,
occupiedseats int,busno varchar(10),driverno varchar(15),totalkms int);
insert into route(routepath,routenametotalseats,occupiedseat,busno,driverno,totalkms)values('Chennai-MIPL,SPkoil,Maraimalainagar,Guduvancheri,Urapakkam,Vandalur,Perungalattur,Tambaram',
'MIPL-Tambaram',60,15,'TN-1234','9685741256',40);
insert into route(routepath,routenametotalseats,occupiedseat,busno,driverno,totalkms)values('Chennai-MIPL,Thambaram,Chrompet,Pallavaram,Mambalam',
'MIPL-Mambalam',60,20,'TN-4567','9685546856',50);
