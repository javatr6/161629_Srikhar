package com.capgemini.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Mainclass {

	public static void main(String[] args) {
		EntityManagerFactory emf = 
        		Persistence.createEntityManagerFactory("jpademo");
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction= em.getTransaction();
        
        transaction.begin();
     Login login=new Login("tom","tom123");
     Login login1=new Login("jerry","jerry123");
     Login login2=new Login("cat","cat123");
      
     Busroute busroute=new Busroute();
     busroute.setRoutePath("mipl sipcot parnur");
     busroute.setRouteName("mipl");
     busroute.setOccupied(10);
     busroute.setTotalSeats(30);
     busroute.setDiverName("tom");
     busroute.setBusNo("tn1235");
     busroute.setTotalKm(40);
     
       
        em.persist(login);
        em.persist(login1);
        em.persist(login2);
        em.persist(busroute);
        transaction.commit();
        em.close();

	}

}
