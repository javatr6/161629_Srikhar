package org.cap.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.cap.model.City;

public class PilotUtil {
public static List<String> getAllCities(){
	List<String> cities=new ArrayList<>();
	cities.add("Chennai");
	cities.add("Tanuku");
	cities.add("Hyderabad");
	cities.add("Banswada");
	return cities;
}

public static List<String> getQualifications() {
	List<String> qualificationsList = new ArrayList<>();
	qualificationsList.add("BE");
	qualificationsList.add("Bsc");
	qualificationsList.add("ME");
	qualificationsList.add("MBA");
	qualificationsList.add("PhD");
	return qualificationsList;
}
}
