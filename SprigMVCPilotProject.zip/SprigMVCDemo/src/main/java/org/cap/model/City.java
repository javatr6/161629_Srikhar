package org.cap.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class City {
@Id
private String city;

public City(String city) {
	super();
	this.city = city;
}

public City() {
	super();
}

public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

@Override
public String toString() {
	return "City [city=" + city + "]";
}

}
