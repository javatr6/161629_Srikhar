package org.cap.controller;

import org.cap.model.Login;
import org.cap.model.Pilot;
import org.cap.service.ILoginService;
import org.cap.service.IPilotService;
import org.cap.util.PilotUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController {
	@Autowired
	private IPilotService pilotService;
	@Autowired
	private ILoginService loginService;
	@RequestMapping(value="/validateLogin",method=RequestMethod.POST)
	public String validateLogin(
			@RequestParam("username")String userName,
			@RequestParam("password")String pwd,
			ModelMap map) {
		Login login=new Login(userName,pwd);
		
		if(loginService.validateLogin(login)) {
			//System.out.println("hi tom");
			//map.addAttribute("userName",userName);
			
			//plain pilot object
			map.addAttribute("pilot",new Pilot());
			map.addAttribute("cities",pilotService.getAllCities());
			map.addAttribute("qualifications",PilotUtil.getQualifications());
			map.addAttribute("pilots",pilotService.getPilotDetails());

			return "redirect:/success";

		}
		return "fail";
						
	}
}
