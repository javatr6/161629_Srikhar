package com.capgemini.model;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Customer");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		Customer tom= new Customer("tom","jerry",45000);
		tom.setDate(LocalDate.now());
		Address address=new Address(1001,"North avenue",tom);
		Customer jack= new Customer("jack","thomson",48000);
		jack.setDate(LocalDate.now());
		Address address1=new Address(1002,"South avenue",jack);
		entityManager.persist(tom);
		entityManager.persist(address);
		entityManager.persist(jack);
		entityManager.persist(address1);
		
		transaction.commit();
		entityManager.close();

	}

}
